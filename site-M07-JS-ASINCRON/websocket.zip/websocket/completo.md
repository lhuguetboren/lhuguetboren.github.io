

### 🖥️ 1. `server.js` – **Servidor Node.js amb WebSocket**

```js
const http = require('http');
const WebSocketServer = require('websocket').server;

const server = http.createServer((req, res) => {
  res.writeHead(200);
  res.end("Servidor de xat actiu");
});

const wsServer = new WebSocketServer({ httpServer: server, autoAcceptConnections: false });
const sales = {}; // { sala1: [conn1, conn2], sala2: [...] }
const usuaris = {}; // { conn: {nick, sala, tipusUsuari} }

wsServer.on('request', (request) => {
  const connection = request.accept(null, request.origin);

  connection.on('message', (message) => {
    const data = JSON.parse(message.utf8Data);

    if (data.tipus === "inici") {
      usuaris[connection] = {
        nick: data.nick,
        sala: data.sala,
        tipusUsuari: data.tipusUsuari
      };

      if (!sales[data.sala]) sales[data.sala] = [];
      sales[data.sala].push(connection);

      broadcast(data.sala, `${data.nick} s'ha unit a la sala.`);
    }

    if (data.tipus === "missatge") {
      const info = usuaris[connection];
      if (info) broadcast(info.sala, `${info.nick}: ${data.text}`);
    }

    if (data.tipus === "expulsar") {
      const info = usuaris[connection];
      if (info.tipusUsuari === "moderador") {
        const sala = info.sala;
        const connexionsSala = sales[sala];
        for (const conn of connexionsSala) {
          if (usuaris[conn] && usuaris[conn].nick === data.nickExpulsat) {
            conn.sendUTF("Has estat expulsat per un moderador.");
            conn.close();
          }
        }
      }
    }
  });

  connection.on('close', () => {
    const info = usuaris[connection];
    if (info) {
      const index = sales[info.sala]?.indexOf(connection);
      if (index !== -1) sales[info.sala].splice(index, 1);
      broadcast(info.sala, `${info.nick} ha sortit de la sala.`);
      delete usuaris[connection];
    }
  });
});

function broadcast(sala, missatge) {
  sales[sala]?.forEach(conn => conn.sendUTF(missatge));
}

server.listen(8089, () => {
  console.log("Servidor WebSocket escoltant al port 8089");
});
```

---

### 🌐 2. `client.html` – **Client Web per al xat**

Aquest fitxer ja el tens pujat (coincideix amb el que has anomenat `client.html`) però aquí el torno a mostrar:

```html
<!DOCTYPE html>
<html>
<head><title>Xat amb Sales</title></head>
<body>
  <h2>Xat WebSocket</h2>
  <label>Nom:</label><input id="nick"><br>
  <label>Sala:</label><input id="sala"><br>
  <label>Tipus:</label>
  <select id="tipusUsuari">
    <option value="usuari">Usuari</option>
    <option value="moderador">Moderador</option>
  </select><br>
  <button onclick="connectar()">Connectar</button>

  <div id="xat"></div>
  <input id="missatge"><button onclick="enviar()">Enviar</button>
  <br>
  <label>Expulsar usuari (moderadors només):</label>
  <input id="nickExpulsat"><button onclick="expulsar()">Expulsar</button>

  <script>
    let socket;

    function connectar() {
      socket = new WebSocket("ws://localhost:8089");
      socket.onopen = () => {
        const nick = document.getElementById('nick').value;
        const sala = document.getElementById('sala').value;
        const tipusUsuari = document.getElementById('tipusUsuari').value;

        socket.send(JSON.stringify({
          tipus: "inici",
          nick,
          sala,
          tipusUsuari
        }));
      };

      socket.onmessage = (evt) => {
        const xat = document.getElementById('xat');
        xat.innerHTML += `<p>${evt.data}</p>`;
      };

      socket.onclose = () => {
        alert("Connexió tancada");
      };
    }

    function enviar() {
      const text = document.getElementById('missatge').value;
      socket.send(JSON.stringify({ tipus: "missatge", text }));
    }

    function expulsar() {
      const nickExpulsat = document.getElementById('nickExpulsat').value;
      socket.send(JSON.stringify({ tipus: "expulsar", nickExpulsat }));
    }
  </script>
</body>
</html>
```

---

### 📦 3. Instal·lació de dependències

Crea un projecte amb Node.js i instal·la el mòdul WebSocket:

```bash
npm init -y
npm install websocket
```

---

### 🚀 Com executar el xat

1. Executa el servidor:

```bash
node server.js
```

2. Obre el `client.html` en diversos navegadors o pestanyes.
3. Prova d'enviar missatges i utilitza el rol de *moderador* per provar l’expulsió.

---

Vols que et generi una versió amb interfície més visual (colors, separació per sales, etc.) o et va bé així de moment?