export type MensajeChat = {
  autor: string;
  contenido: string;
  timestamp: string;
};
