
# CodeTutor: Comunicació Asíncrona amb JavaScript

## 🔹 Mòdul 1: Què és l’asincronia?

**Definició bàsica:**
> Quan fem una petició **asíncrona**, el navegador no es bloqueja esperant la resposta, sinó que continua executant el codi. Quan la resposta arriba, es gestiona amb una **callback** o una **promesa**.

📘 Exemples clàssics d’ús:

- Validar formularis sense recarregar la pàgina.
- Mostrar resultats mentre escrius (autocompletar).
- Rebre dades del servidor en temps real (xat, dashboards).

---

## 🔹 Mòdul 2: AJAX amb `XMLHttpRequest`

### ✅ Exemple GET

```javascript
let xmlHttp = new XMLHttpRequest();
let url = "valida.php?nom=cristian&edat=8";

xmlHttp.open("GET", url, true);
xmlHttp.onreadystatechange = function () {
  if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
    console.log(xmlHttp.responseText);
  }
};
xmlHttp.send(null);
```

🔍 **Punts clau:**
- `readyState === 4`: la resposta s’ha completat.
- `status === 200`: tot ha anat bé.

### ✅ Exemple POST

```javascript
let xmlHttp = new XMLHttpRequest();
xmlHttp.open("POST", "valida.php", true);
xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
xmlHttp.onreadystatechange = function () {
  if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
    console.log(xmlHttp.responseText);
  }
};
xmlHttp.send("nom=cristian&edat=88");
```

---

## 🔹 Mòdul 3: AJAX amb `fetch()`

### ✅ Exemple GET

```javascript
fetch("valida.php?nom=cristian&edat=8", {
  method: "GET",
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.log("Error:", error));
```

### ✅ Exemple POST

```javascript
fetch("valida.php", {
  method: "POST",
  body: "nom=cristian&edat=88",
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.log("Error:", error));
```

---

## 🔹 Mòdul 4: Enviament de fitxers amb `FormData`

### Amb `XMLHttpRequest`:

```javascript
let form = new FormData();
form.append("arxiu", document.getElementById("arxius").files[0]);

let xmlHttp = new XMLHttpRequest();
xmlHttp.open("POST", "ajax.php", true);
xmlHttp.send(form);
```

### Amb `fetch()`:

```javascript
let form = new FormData();
form.append("arxiu", document.getElementById("arxiu").files[0]);

fetch("http://localhost:8089/endpoint", {
  method: "POST",
  body: form
})
.then(response => response.json())
.then(data => console.log(data));
```

---

## 🔹 Mòdul 5: Comparativa `XMLHttpRequest` vs `fetch()`

| Característica         | `XMLHttpRequest`                   | `fetch()`                            |
|------------------------|-------------------------------------|--------------------------------------|
| Basat en               | Callbacks                          | Promeses (`.then()`, `.catch()`)    |
| Sintaxi                | Verbosa                            | Clara i moderna                     |
| Gestió d'errors        | Manual amb `status` i `readyState` | Més simple amb `.catch()`           |
| Suport JSON            | Manual (`JSON.parse()`)            | Integrat (`response.json()`)        |
| Cancel·lació           | ❌                                  | ✅ Amb `AbortController`             |

---

## 🔹 Mòdul 6: Errors habituals

- ❌ Oblidar `setRequestHeader` en POST amb `XMLHttpRequest`.
- ❌ No verificar `response.ok` amb `fetch()`.
- ❌ Format incorrecte del `body` en peticions POST.
- ❌ Error CORS: falta l’encapçalament al servidor.

---

## 🔚 Mòdul 7: Exercici pràctic

1. Crea una pàgina amb un `<form>` per enviar el nom d’un usuari.
2. Captura el `submit` amb JavaScript.
3. Envia el nom al servidor amb `fetch()` o `XMLHttpRequest`.
4. Mostra la resposta del servidor (text, JSON o XML) dins un `<div>`.

---
