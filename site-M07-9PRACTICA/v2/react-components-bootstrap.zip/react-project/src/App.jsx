import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './components/Login';
import Chat from './components/Chat';
import Sala from './components/Sala';
import Editor from './components/Editor';
import UserList from './components/UserList';

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-light bg-light mb-4">
        <div className="container-fluid">
          <span className="navbar-brand">Projecte Col·laboratiu</span>
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">Login</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chat">Chat</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/sala">Sala</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/editor">Editor</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/usuaris">Usuaris</Link>
            </li>
          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/sala" element={<Sala />} />
        <Route path="/editor" element={<Editor />} />
        <Route path="/usuaris" element={<UserList />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;