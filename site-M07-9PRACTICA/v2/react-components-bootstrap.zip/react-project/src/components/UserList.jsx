import React from 'react';

function UserList() {
  return (
    <div className="container">
      <h2 className="mb-4">Llista d'Usuaris</h2>
      <ul className="list-group">
        <li className="list-group-item">Usuari1</li>
        <li className="list-group-item">Usuari2</li>
        <li className="list-group-item">Usuari3</li>
      </ul>
    </div>
  );
}

export default UserList;