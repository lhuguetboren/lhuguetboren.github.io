import React from 'react';

function Chat() {
  return (
    <div className="container">
      <h2 className="mb-4">Chat</h2>
      <div className="border p-3 mb-3" style={{ height: '200px', overflowY: 'auto' }}>
        <p><strong>Usuari1:</strong> Hola! (missatge d'exemple)</p>
        <p><strong>Usuari2:</strong> Hi ha algú?</p>
      </div>
      <form>
        <div className="mb-3">
          <input 
            type="text" 
            className="form-control" 
            placeholder="Escriu un missatge..." 
            disabled 
          />
        </div>
        <button type="submit" className="btn btn-secondary" disabled>Enviar</button>
      </form>
    </div>
  );
}

export default Chat;