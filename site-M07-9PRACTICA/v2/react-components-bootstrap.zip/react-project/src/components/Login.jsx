import React from 'react';

function Login() {
  return (
    <div className="container" style={{ maxWidth: '400px', marginTop: '2rem' }}>
      <h2 className="mb-4">Login</h2>
      <form>
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Usuari</label>
          <input type="text" id="username" className="form-control" placeholder="Introdueix l'usuari" />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Contrasenya</label>
          <input type="password" id="password" className="form-control" placeholder="Introdueix la contrasenya" />
        </div>
        <button type="submit" className="btn btn-primary w-100" disabled>Entra</button>
      </form>
    </div>
  );
}

export default Login;