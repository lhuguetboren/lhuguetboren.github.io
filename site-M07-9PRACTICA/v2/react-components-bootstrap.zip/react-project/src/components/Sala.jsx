import React from 'react';

function Sala() {
  return (
    <div className="container">
      <h2 className="mb-4">Sala</h2>
      <p className="text-muted">
        *Aquest és el placeholder de la sala col·laborativa.* Aquí es combinaran el xat, l'editor i la llista d'usuaris.
      </p>
    </div>
  );
}

export default Sala;