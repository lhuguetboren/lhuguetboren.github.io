import React from 'react';

function Editor() {
  return (
    <div className="container">
      <h2 className="mb-4">Editor Col·laboratiu</h2>
      <textarea 
        className="form-control" 
        rows="10" 
        placeholder="Escriu aquí el text col·laboratiu..." 
        disabled
      />
    </div>
  );
}

export default Editor;