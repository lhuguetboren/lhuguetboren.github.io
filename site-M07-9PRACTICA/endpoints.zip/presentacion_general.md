
# 🧩 Proyecto de Aula — Sistema de Chat para Centro de Formación

## 💡 Descripción
Diseñar y desarrollar una aplicación web de mensajería en tiempo real para un centro educativo, con funcionalidades  como:
- Chat en tiempo real
- Registro de usuarios
- Envío de archivos
- Consulta y descarga del historial
---

## 🎯 Objetivos didácticos
- Entender la diferencia entre WebSockets y AJAX
- Diseñar y consumir APIs REST
- Trabajar en equipo usando roles rotativos
- Consolidar conocimientos de frontend y backend
---

## 🧱 Tecnologías recomendadas
- React o Vue (Frontend)
- Node.js + Express (Backend)
- MongoDB o PostgreSQL (Base de datos)
- Socket.IO (WebSockets)
- Fetch API (AJAX)
---

## 🔁 Dinámica
Trabajo por parejas, rotando entre:
- **Revisor**: revisa, aconseja
- **Ejecutor**: desarrolla, implementa, resuelve
---

## 📈 Producto final
Una app web funcional que permita:
- Crear usuarios y acceder al sistema
- Intercambiar mensajes en tiempo real
- Subir y descargar archivos por el chat
- Descargar conversación histórica en formato `.txt` o `.json`

---

## 📦 Entregables
- Código fuente (frontend y backend)
- Memoria técnica
- Rúbrica de autoevaluación
- Presentación/demostración final
---
