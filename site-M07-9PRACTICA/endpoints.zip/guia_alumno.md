
# 🧑‍🎓 Guía del Alumno — Proyecto Chat para Centro de Formación

## 🎯 Objetivo
Desarrollar una aplicación web de chat en tiempo real con:
- WebSocket (Socket.IO)
- Envío de archivos
- Autenticación de usuarios
- Descarga del historial de conversaciones mediante `fetch`

## 🧠 Aprendizajes clave
- Comunicación en tiempo real con WebSocket
- AJAX y asincronía con `fetch`
- Upload y descarga de archivos
- Diseño de API REST
- Trabajo en parejas alternando roles: director y ejecutor

## 🛠️ Stack sugerido
- **Frontend:** React o Javascript básico
- **Backend:** Node.js + Express
- **WebSocket:** Socket.IO
- **AJAX:** Fetch API
- **Almacenamiento de archivos:** local 

## 🔁 Modalidad de trabajo
- Trabajo por parejas
- Se alternan los roles cada sesión:
  - **Director de proyecto**: supervisa, organiza, planifica
  - **Ejecutor**: desarrolla, implementa, prueba

## 📋 Fases del proyecto

### 1. Diseño
- Definición de funcionalidades mínimas
- Diseño de interfaz

### 2. Desarrollo
#### Backend:
- Registro e inicio de sesión
- Comunicación por WebSocket
- API para historial y archivos

#### Frontend:
- Chat en tiempo real
- Subida/descarga de archivos
- Botón de descarga de historial (`fetch`)

### 3. Evaluación
- Demo funcional
- Memoria técnica
- Valoración revisión

## 📎 Requisitos funcionales
- Registro/Login
- Chat por WebSocket
- Envío de archivos
- Descarga de historial en `.json` o `.txt` usando `fetch`
