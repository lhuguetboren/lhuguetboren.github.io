
// Cargar datos desde mock_data.json
import mockData from './mock_data.json';

// Obtener todos los usuarios
export function getUsuarios() {
  return mockData.usuarios;
}

// Obtener usuario por ID
export function getUsuarioById(id) {
  return mockData.usuarios.find(u => u.id === id);
}

// Obtener todas las salas disponibles
export function getSalas() {
  return mockData.salas;
}

// Obtener salas de un usuario
export function getSalasDeUsuario(userId) {
  return mockData.salas.filter(sala => sala.participantes.includes(userId));
}

// Obtener mensajes de una sala
export function getMensajesDeSala(salaId) {
  return mockData.mensajes.filter(m => m.salaId === salaId);
}

// Enviar un mensaje (simulado, no persistente)
export function enviarMensaje({ salaId, emisorId, contenido }) {
  const nuevoMensaje = {
    id: 'm' + (mockData.mensajes.length + 1),
    salaId,
    emisorId,
    contenido,
    timestamp: new Date().toISOString()
  };
  mockData.mensajes.push(nuevoMensaje); // Simulado: en un entorno real, esto no persistiría
  return nuevoMensaje;
}
