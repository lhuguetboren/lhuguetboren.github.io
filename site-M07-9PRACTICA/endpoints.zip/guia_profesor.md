
# 👨‍🏫 Guía del Profesor — Proyecto Chat para Centro de Formación

## 🎯 Objetivo del proyecto
Evaluar la capacidad del alumnado para desarrollar una aplicación de chat en tiempo real que integre:
- WebSocket
- Envío/descarga de archivos
- AJAX con `fetch`
- API REST
- Roles colaborativos

## 🔧 Supervisión de roles
- Promover alternancia de **director de proyecto** y **ejecutor**
- Evaluar la comunicación y cooperación en pareja

## 🗂️ Evaluación sugerida (rúbrica)
| Criterio                         | Puntos |
|----------------------------------|--------|
| Funcionalidad del chat           | 3      |
| Subida y envío de archivos       | 2      |
| Descarga con fetch               | 2      |
| Uso adecuado de WebSocket        | 2      |
| Código y organización general    | 3      |
| Trabajo en equipo                | 2      |
| Memoria técnica                  | 1      |
| **Total**                        | **15** |

## 📂 Archivos clave esperados
- Código backend (`/server`)
- Código frontend (`/client`)
- README con instrucciones
- Memoria técnica (PDF o MD)

## 🧾 Issues recomendados
- 1. Autenticación (register/login)
- 2. Chat WebSocket (join/send)
- 3. Envío de archivos
- 4. Descarga de historial con fetch
- 5. Interfaz de usuario
- 6. Documentación y demo

## ⏱️ Organización temporal (orientativa)
| Semana | Actividad                     |
|--------|-------------------------------|
| 1      | Preparación        |
| 2      | WebSocket + envío de mensajes |
| 3      | Envío de archivos + fetch     |
| 4      | Finalización y demo           |
