
---

## 📡 Esquema de Endpoints REST (HTTP)

### 🧾 Autenticación de usuarios
| Método | Endpoint              | Descripción                         |
|--------|-----------------------|-------------------------------------|
| POST   | `/api/login`          | Inicio de sesión, devuelve token    |
|
---

### 💬 Conversaciones y ~~mensajes~~
| Método | Endpoint                            | Descripción                               |
|--------|-------------------------------------|-------------------------------------------|
| GET    | `/api/conversaciones`              | Lista de conversaciones del usuario       |
| GET    | `/api/conversaciones/:id`          | Descargar historial como `.json` o `.txt` |
| POST   | `/api/conversaciones/:id/responder`| (Opcional) Enviar respuesta puntual vía AJAX|

---

### 📁 Archivos
| Método | Endpoint                 | Descripción                          |
|--------|--------------------------|--------------------------------------|
| POST   | `/api/archivos/upload`   | Subir archivo al chat (con FormData) |
| GET    | `/api/archivos/:id`      | Descargar archivo                    |

---

## 🔌 Eventos WebSocket (Socket.IO)

### 📥 Entrada y salida
| Evento        | Dirección     | Descripción                        |
|---------------|---------------|------------------------------------|
| `joinRoom`    | Cliente → Servidor | Unirse a una sala (conversación)    |
| `leaveRoom`   | Cliente → Servidor | Salir de la sala                    |

---

### 🗨️ Mensajes
| Evento         | Dirección     | Descripción                        |
|----------------|---------------|------------------------------------|
| `sendMessage`  | Cliente → Servidor | Enviar mensaje a una sala           |
| `receiveMessage` | Servidor → Cliente | Mensaje recibido en tiempo real     |

---

### 📦 Archivos (notificación)
| Evento         | Dirección     | Descripción                        |
|----------------|---------------|------------------------------------|
| `fileSent`     | Servidor → Cliente | Notificación de nuevo archivo       |

---

